library(dbplyr)
library(bench)
# Pregunta 1 --------------------------------------------------------------
x <- c(1:1000000)

es_divisible <- function(x, a){ #Determina cuales vectores son divisibles
  v <- vector(mode= "numeric")
  v <-  x[x %% a == 0] 
  return(length(v))
}  
es_divisible1 <- function(x, a) x[x %% a == 0]

cantidad_divisibles <- function(x,a){ #Determina la longitud del vector 
  return(length(es_divisible1(x,a)))
} 

ciclo <- function(x,a){
  count = 0
  for (i in x) {
    if(i%%a==0){
      
      count= count + 1
    }
    
  }
  return(count)
}
ciclo(x,7)
es_divisible(x,2)

#Prueba 
cantidad_divisibles(x,5)
tiempo <- mark(
  "sin ciclo" = es_divisible(x,17),
   "con ciclo" = cantidad_divisibles(x,17), 
    relative = T)

tiempo
# Pregunta 2 --------------------------------------------------------------

es_primo <- function(n){
  if(n%%2==0 & n!=2){
    return(FALSE)
  }
  ifelse(sum(n %% (1:floor(n/2)) == 0) > 1, FALSE, TRUE )
} 




es_primo1 <- function(n){
  if(n%%2==0 & n!=2){
    return(FALSE)
  }
  vector <- vector(mode = "numeric", length = n-2)
  vector <- (2:n)
  for(i in vector){
    if(i==n-1 | n==2){
      return(TRUE)
    }
    if(n %% vector[i]==0){
      return(FALSE)
    }
    
  }
    
  }
  
es_primo1(997)









es_primo(14)
esDivisor <- function(a,b){
  if(b%%a==0){
    return(TRUE)
    
  }
  else{
    return(FALSE)
  }
  
}
esPrimo <-function(n){
  if(n<2){
    return(FALSE)
  }
  else{
    if(n%%2==0 & n!=2){
      return(FALSE)
    }
    else{
      c<-3
      while (c<n) {
        if(esDivisor(c,n)){
          
          return(FALSE)
        }
        else{
          c<-c+1
        }
        
      }
      return(TRUE)
    }
  }
  
}
tiempo1 <- mark(
  "resumido" = es_primo1(4259),
  "normal" = esPrimo(4259), 
  relative = T)
es_primo1(5)
tiempo1

# Pregunta 3 --------------------------------------------------------------

calcular_vp_anualidad_inmediata <- function(i,n, A, k){
  n_years <- c(1:n)
  vp <- vector(mode = "numeric", length = length(A))
  vp <- A*((1+i)/k)^-n_years
  result <- sum(vp)
  return(result)
}


# Pregunta 4 --------------------------------------------------------------

convertir_tasa_nominal <- function(tasa, m){
  r= ((1 + tasa/100*m)^m -1)*100
  return(r)
}

# Pregunta 4.1 ------------------------------------------------------------

v_1 <- vector(mode = "numeric", length = 10)
v_1 <- c(100, 100, 100, 100, 100, 300, 300, 300, 300, 300)
tasa_nueva <- convertir_tasa_nominal(6, 1)
calcular_vp_anualidad_inmediata(tasa_nueva, 10, v_1, 1 )


# Pregunta 4.2 ------------------------------------------------------------

vp <- vector(mode = "numeric", length = 10)
v_2 <- c(200, 300, 400, 500, 600, 600, 600, 600, 600, 600)
tasa_nueva1 <- convertir_tasa_nominal(5.5, 1)
calcular_vp_anualidad_inmediata(tasa_nueva1, 10, v_2, 1 )
  

# Pregunta 4.3 ------------------------------------------------------------

v_3 <- rep(1000: 50)

calcular_vp_anualidad_inmediata()








