

library(readxl)
library(dplyr)
library(ggplot2)
tabla <- read_excel('Tabla de vida.xls')


# Pregunta 1 --------------------------------------------------------------

simula_vida <- function( edad, tabla )
{
  muestras <- rep(1, nrow(tabla)-edad )
  for ( i in 1:length(muestras) )
  {
    qx <- tabla[edad+i,2]
    muestras[i] <- sample(c(0,1),1,replace = F, prob = c( qx,1-qx ) )
  }
  return(edad-1 + (1:length(muestras))[muestras==0][1]  )
}

calcular_prima <- function(edad, tabla, n, tc, ti, SA){
  tiempo <-proc.time()
  x <- vector(mode = "numeric", length = n)
  
  for(i in 1:n){
    x[i] = simula_vida(edad, tabla)

  }
  #print(x)
  vector <- subset(x, x < edad +tc)
  #print(vector)
  if(length(vector) == 0){
    return(0)
  }
  k <- length(vector)
  #print(vector)
  #print(k)
  prima <- 0

  for(j in 1:k){
    prima <- (1/(1+ti))^(vector[j] - edad) + prima 
    print(1/(1+ti))
    #print(prima)
    
  }
  #print(SA/n)
  prima <- prima * (SA/n)
  tiempo1 <- proc.time()-tiempo
  print(tiempo1)
  return(prima)
  
}
calcular_prima(40, tabla, 100, 8, 0.06, 10000)

print("b")

# Pregunta 2 --------------------------------------------------------------

calcular_prima(10, tabla, 10000, 6, 0.04, 1000000)

calcular_prima(20, tabla, 10000, 10, 0.04, 2000000.00)

calcular_prima(32, tabla, 10000, 4, 0.04, 500000)

calcular_prima(40, tabla, 10000, 1, 0.04, 300000.00 )

calcular_prima(50, tabla, 10000, 10, 0.04, 2500000.00)

calcular_prima(66, tabla, 10000, 7, 0.04, 4000000.00 )



# Pregunta 3 --------------------------------------------------------------

data <- data.frame(
  "Edad" = 10:60, 
  "Prima" = NA
)


data$Prima[1] <- calcular_prima(data$Edad[1], tabla, 1, 20, 0.06, 1000000)
print(data$Prima[1])

for(i in 1:51){
  data$Prima[i] <- calcular_prima(data$Edad[i], tabla, 1000, 20, 0.06, 1000000)
}

grafico_1 <- ggplot(data, mapping = aes(x = Edad, y= as.numeric(Prima))) + geom_line(color = "purple") + 
  labs(x= "Edades", y= "Primas", 
       title = "Primas estimadas de las edades de 10 a 60 a�os")  + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black"))


data$Prima <- calcular_prima(data$Edad, tabla, 25, 20, 0.06, 1000000)

calcular_prima(11, tabla, 10, 20, 0.06, 1000000)



