#Primer ejercicio 
numerosMenores <- function(a,b,n,x){
  c <-runif(n,min=a, max=b)
  for (i in 1: length(c))
    if (c[i]<x){
      print(c[i])
    }
}

numerosMenores(1,5,8,3)

#Segundo ejercicio
esDivisor <- function(a,b){
  if(b%%a==0){
    return(TRUE)
    
  }
  else{
    return(FALSE)
  }
  
}
esDivisor(4,8)

#Tercer ejercicio
CantidadMultiplos<- function(matriz, n){
  contador <-0
  for(i in 1: nrow(matriz)){
    for(j in 1: ncol(matriz)){
      if(esDivisor(n,matriz[i,j])){
        #print(matriz[i,j])
        contador <-contador+1
      }
    }
  }
  return(contador)
}
m <-matrix(c(1,2,3,4,18,6),nrow=2,ncol=3, byrow=TRUE)

CantidadMultiplos(m,3)

#Cuarto ejercicio
esPrimo <-function(n){
  if(n<2){
    return(FALSE)
  }
  else{
    if(n%%2==0){
      return(FALSE)
    }
    else{
      c<-3
      while (c<n) {
        if(esDivisor(c,n)){
          
          return(FALSE)
        }
        else{
          c<-c+1
        }
        
      }
      return(TRUE)
    }
  }
  
}
esPrimo(29)