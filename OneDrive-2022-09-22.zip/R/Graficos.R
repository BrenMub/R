
library(readxl)
library(ggplot2)
library(tidyverse)

datos <- read_excel('Datos proyecto v5.xlsx')

datos <- datos[-c(1), ]
colnames(datos) <- c('Tipo_de_titulo', 'Fecha_de_vencimiento','Periodicidad','Cupon', 'Precio')




datos$Fecha_de_vencimiento <- as.numeric(datos$Fecha_de_vencimiento)
datos$`Precio`<- as.numeric(datos$`Precio`)
datos$`Fecha_de_vencimiento` <-  as.Date(datos$`Fecha_de_vencimiento`, origin="1899-12-30")

datos$Tipo_de_titulo[2:7] <- "Bonos Cero Cup�n"
datos$Tipo_de_titulo[9:37] <- "T�tulos Cuponados"

# Grafico 1 ---------------------------------------------------------------
grafico_1 <- ggplot(datos, mapping = aes(x = Fecha_de_vencimiento, y= Precio)) + geom_point(color = "red") + geom_line(color = "red") +
  ggtitle("Gr�fico 1: Fecha de vencimiento vs Precio") + xlab("Fecha de vencimiento") + ylab("Precio (%)") + 
  theme( panel.background = element_blank(), axis.line = element_line(colour = "black")) + theme_light()

grafico_1


# Grafico 2 ---------------------------------------------------------------

#cantidad_bonos <- datos %>% group_by(Periodicidad) %>% summarise(count())
cantidad_bonos_por_periodo <- datos %>% count(Periodicidad)
cantidad_bonos_por_periodo$Periodicidad <-as.numeric(cantidad_bonos_por_periodo$Periodicidad)
cantidad_bonos_por_periodo$n <-as.numeric(cantidad_bonos_por_periodo$n)

grafico_2 <- ggplot(cantidad_bonos_por_periodo, mapping = aes(x = Periodicidad, y = n, fill= Periodicidad)) +
  geom_bar(stat="identity") + xlab("Periodicidad")+ ylab("Cantidad de Bonos")+ ggtitle("Gr�fico 2: Cantidad de bonos por periodicidad") +
  theme_light()
  

#ggplot(cantidad_bonos_por_periodo, mapping = aes(x = Periodicidad, y = n, fill= Periodicidad)) + 
  #geom_bar(stat="identity") 
  
  

  
#ggplot(cantidad_bonos_por_periodo, mapping = aes(x = Periodicidad, y = n, fill= Periodicidad)) + 
  geom_bar(stat="identity") 


# Grafico 3 ---------------------------------------------------------------

cantidad_bonos <- datos %>% group_by(Tipo_de_titulo) %>% summarise(Cantidad = n())

grafico_3 <- ggplot(cantidad_bonos, mapping = aes(x = Tipo_de_titulo, y = Cantidad, fill= Tipo_de_titulo)) +
  geom_bar(stat="identity") + xlab("Tipo de Bono")+ ylab("Cantidad") + ggtitle("Gr�fico 3: Cantidad de t�tulos por tipo de bono") + 
  theme(legend.position = 'none') 


  
  
  ggplot(cantidad_bonos, mapping = aes(x = Tipo_de_titulo, y = Cantidad, fill= Tipo_de_titulo)) + 
  geom_bar(stat="identity") 
  
  
  ggplot(cantidad_bonos, mapping = aes(x=Tipo_de_titulo, color = Cantidad)) + 
  geom_histogram(color="red", fill="red")








