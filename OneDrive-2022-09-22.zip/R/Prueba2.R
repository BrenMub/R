
library(readxl)
tabla <- read_excel('Tabla de vida.xls')


# Pregunta 1 --------------------------------------------------------------

simula_vida <- function(edad, tabla, n, tc)
{
  tiempo <-proc.time()
  #vidas1 <- vector(mode = "numeric", length = n)
  x <- vector(mode = "numeric", length = n)
  for(j in 1:n){
    muestras <- rep(1, nrow(tabla)-edad )
    for ( i in 1:length(muestras) )
    {
      qx <- tabla[edad+i,2]
      muestras[i] <- sample(c(0,1),1,replace = F, prob = c( qx,1-qx ) )
    }
    if(edad-1 + (1:length(muestras))[muestras==0][1] < tc+edad){
      #print(edad-1 + (1:length(muestras))[muestras==0][1])
      x[j] <-1
    }
    else{
      #print(edad-1 + (1:length(muestras))[muestras==0][1])
      x[j] <- 0
    }
  }
  tiempo1 <- proc.time()-tiempo
  print(tiempo1)
  muertes <- length(which(x==1))
  #print(x)
  return(muertes)
  
}


costo_prima <- function(edad, tasa, n, SA, tc){
  
}


simula_vida(10, tabla, 100, 55)




