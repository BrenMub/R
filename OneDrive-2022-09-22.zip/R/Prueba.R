install.packages("jrvFinance")

library(jrvFinance)
library(readxl)
library(dbplyr)
library(tidyverse)

datos <- read_excel('Datos proyecto v5.xlsx')
datos <- datos[-c(1), ]
colnames(datos) <- c('Tipo_de_titulo', 'Fecha_de_vencimiento','Periodicidad','Cupon', 'Precio')




datos$Fecha_de_vencimiento <- as.numeric(datos$Fecha_de_vencimiento)
datos$`Precio`<- as.numeric(datos$`Precio`)
datos$`Fecha_de_vencimiento` <-  as.Date(datos$`Fecha_de_vencimiento`, origin="1899-12-30")

datos$Tipo_de_titulo[2:7] <- "Bonos Cero Cup�n"
datos$Tipo_de_titulo[9:37] <- "T�tulos Cuponados"



DiasHastaMaduracion <- difftime(datos$Fecha_de_vencimiento ,as.Date("2021-06-01", "%Y-%m-%d ") , units = c("days"))


datos <- datos %>% mutate(dias_hasta_maduracion= DiasHastaMaduracion)
x <- ()

lm(Precio~, data = datos)
