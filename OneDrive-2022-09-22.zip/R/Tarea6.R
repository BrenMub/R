
library(dbplyr)
library(bench)

# Pregunta 1 --------------------------------------------------------------

x <- c(1:10000)

cantidad_divisibles <- function(x, a){ #Determina cuantos vectores son divisibles por a
  v <- vector(mode = "numeric")
  v <-  x[x %% a == 0] 
  return(length(v))
} 

# Prueba
cantidad_divisibles(x,5)


# Pregunta 2 --------------------------------------------------------------

es_primo1 <- function(n){ 
  if(n%%2==0 & n!=2){
    return(FALSE)
  }
  vector <- vector(mode = "numeric", length = n-2)
  vector <- (2:n)
  for(i in vector){
    if(i==n-1 | n==2){
      return(TRUE)
    }
    if(n %% vector[i]==0){
      return(FALSE)
    }
    
  }
  
}

# Prueba 
es_primo(7)

#Nota: este es aun mas eficiente con numeros primos

es_primo <- function(n){ #Este c�digo es m�s eficiente con numeros primos 
  if(n%%2==0 & n!=2){
    return(FALSE)
  }
  ifelse(sum(n %% (1:floor(n/2)) == 0) > 1, FALSE, TRUE )
} 

# Pregunta 3 --------------------------------------------------------------

calcular_vp_anualidad_inmediata <- function(i,n, A, k){
  n_years <- c(1:n)
  vp <- vector(mode = "numeric", length = length(A))
  vp <- A*((1+i)/k)^-n_years
  result <- sum(vp)
  return(result)
}


# Pregunta 4 --------------------------------------------------------------

convertir_tasa_nominal <- function(tasa, m){
  r= ((1 + tasa/100*m)^m -1)*100
  return(r)
}
convertir_tasa_convertible <- function(tasa, m) return(tasa/100*m)


# Pregunta 4.a ------------------------------------------------------------

v_1 <- vector(mode = "numeric", length = 10)
v_1 <- c(100, 100, 100, 100, 100, 300, 300, 300, 300, 300)

tasa_nueva <- convertir_tasa_nominal(6, 1)
calcular_vp_anualidad_inmediata(tasa_nueva, 10, v_1, 1 )



# Pregunta 4.b ------------------------------------------------------------

vp <- vector(mode = "numeric", length = 10)
v_2 <- c(200, 300, 400, 500, 600, 600, 600, 600, 600, 600)

tasa_nueva1 <- convertir_tasa_nominal(5.5, 1)
calcular_vp_anualidad_inmediata(tasa_nueva1, 10, v_2, 1 )


# Pregunta 4.c ------------------------------------------------------------

v_3 <- rep(1000, 50)
tasa_nueva2 <- convertir_tasa_convertible(6, 2)
calcular_vp_anualidad_inmediata(tasa_nueva2, 50, v_3, 2)



