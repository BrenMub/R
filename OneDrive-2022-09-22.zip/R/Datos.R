library(lubridate)
library(dplyr)
library(tidyverse)
library(ggplot2)
OilPrice <- read_csv2('OilPrice.csv')
#datos_pensiones.csv <- read_delim('datos_pensiones.csv', " ")

data1 <-OilPrice$Fecha
data1 <- as.Date(data1, format= '%b %d %Y')
data <- OilPrice
data$Fecha <- as.Date(data$Fecha, format= '%b %d %Y' )
fecha1 <- data1[1]
fecha1 <- as.Date(fecha1, format= '%b %d %Y')
fecha2 <- data1[length(data1)]
fecha2 <- as.Date(fecha2, format= '%b %d %Y')





# Ejercicio 1  ------------------------------------------------------------

secuencia_en_dias <- function(fecha1, fecha2, data1){
  vector_fechas <-seq(fecha1,fecha2, by = "days")
  #print(vector_fechas)
  x <- setdiff(vector_fechas, data1)
  x <- as.Date(x, origin="1970-01-01") #Se coloco este origen pues sin esto las fechas aparecen desfasadas
  return(x)
}


# Ejercicio 2 -------------------------------------------------------------

y <- secuencia_en_dias(fecha1,fecha2, data1)
data2 <-data.frame("Fecha" = y, "Precio" = NA)
data3 <- rbind(data, data2)
data3 <- arrange(data3, Fecha)
data31 <- data.frame(data3)
prom <- summarise(data, mean(Precio))
data31$Precio[is.na(data31$Precio)] <- prom$`mean(Precio)`

print(prom)


# Pregunta 3 --------------------------------------------------------------

data3 <- mutate(data3, numero_semana = paste(epiweek(Fecha), "-", year(Fecha)))
#promedios <- data3 %>% group_by(numero_semana) %>% summarise(promedio_semana = mean(Precio))

data3 <- group_by(data3, numero_semana)
data3 <- mutate(data3, promedio_semana = mean(as.numeric(Precio), na.rm= TRUE))
data3 <- ungroup(data3)
data3 <- mutate(data3, Precio= ifelse(test = is.na(Precio), 
                                      yes = promedio_semana,
                                      no = Precio))

# Pregunta 4 --------------------------------------------------------------
grafico_1 <- ggplot(data31, mapping = aes(x = Fecha, y= as.numeric(Precio))) + geom_point(color = "red") + 
  labs(x= "Fechas", y= "Precios", 
  title = "Precio del aceite por fecha calculado con un promedio de todos los datos")  + 
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black")) # Si se realiza con data31[1:100] se nota que la linea no es constante


grafico_2 <- ggplot(data3, mapping = aes(x =Fecha, y=as.numeric(Precio))) + geom_point(color = "blue") +
  labs(x= "Fechas", y= "Precios", 
       title = "Precio del aceite por fecha calculado con un promedio por semana") +  
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), 
        panel.background = element_blank(), axis.line = element_line(colour = "black"))


#Me parece que la mejor forma de calcular el precio de datos faltantes  es calculando un promedio semanal
#pues en el grafico_1 los datos varian mucho de los cercanos en ocasiones
grafico_2
class(data3$Precio[1])



# Pregunta 5 --------------------------------------------------------------

dataP <-datos_pensiones
fecha3 <-"2021/11/08"
fecha3 <-as.Date(fecha3, format= "%Y/%m/%d")

dataP$fnacimien <-as.character(dataP$fnacimien, format= "%Y%m%d")
dataP$fnacimien <-as.Date(dataP$fnacimien, format= "%Y%m%d")


dataP <- mutate(dataP, "Edad" =  as.double(floor((fecha3 - dataP$fnacimien )/365)))

#Datos segun sexo
sexo <- dataP %>% group_by(sexo, Edad) %>% summarise(Cantidad = n())

#Datos segun riesgo 
riesgo <- dataP %>% group_by(riesgo, Edad) %>% summarise(Cantidad = n())



# Pregunta 6 --------------------------------------------------------------

t <- data.frame(cut_interval(dataP$Edad, length = 4)) #Se realizan intervalos de 4 en 4 
#t <- cut_interval(dataP$Edad, length = 4)
dataP$Intervalo <- t$cut_interval.dataP.Edad..length...4.
temp1 <- dataP %>% group_by(Intervalo) %>% summarise(Monto_Promedio = mean(monto_movi))
temp2 <- dataP %>% group_by(Intervalo) %>% summarise(Monto_minimo = min(monto_movi))
temp_3 <- dataP %>% group_by(Intervalo) %>% summarise(Monto_maximo = max(monto_movi))

