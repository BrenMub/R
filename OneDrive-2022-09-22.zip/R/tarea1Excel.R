install.packages("readxl")
install.packages("tidyverse")

library(readxl)
datosPensiones <- read_excel("C:/Users/nuzum_000.CUARTODEESTUDIO/Downloads/datos_pensiones.xlsx")
library(tidyverse)
datosPensiones %>% group_by(sexo) %>% summarise(promedio =mean("monto pensi�n actual"))
datosPensiones  %>% group_by("tipo de pensi�n") %>% summarise(max =max(edad))
datosPensiones %>% count(riesgo)