

library(readxl)
tabla <- read_excel('Tabla de vida.xls')



# Pregunta 1 --------------------------------------------------------------
simula_vida <- function(edad, tabla, n, tc)
{
  tiempo <-proc.time()
  #vidas1 <- vector(mode = "numeric", length = n)
  x <- vector(mode = "numeric", length = n)
  for(j in 1:n){
    muestras <- rep(1, nrow(tabla)-edad )
    for ( i in 1:length(muestras) )
    {
      qx <- tabla[edad+i,2]
      muestras[i] <- sample(c(0,1),1,replace = F, prob = c( qx,1-qx ) )
    }
    if(edad-1 + (1:length(muestras))[muestras==0][1] < tc+edad){
      #print(edad-1 + (1:length(muestras))[muestras==0][1])
        x[j] <-1
    }
    else{
      #print(edad-1 + (1:length(muestras))[muestras==0][1])
      x[j] <- 0
    }
  }
  tiempo1 <- proc.time()-tiempo
  print(tiempo1)
  return(x)
  
}

simula_vida(10, tabla, 10000, 55)





simula_vida <- function(edad, tabla, n)
{
  tiempo <-proc.time()
  #vidas1 <- vector(mode = "numeric", length = n)
  #vidas1 <- c(1:n)
  x <- vector()
  for(i in c(1:n)){
    muestras <- rep(1, nrow(tabla)-edad )
    for ( i in 1:length(muestras) )
    {
      qx <- tabla[edad+i,2]
      muestras[i] <- sample(c(0,1),1,replace = F, prob = c( qx,1-qx ) )
    }
    valor <- edad-1 + (1:length(muestras))[muestras==0][1]
    #print(valor)
    x<- append(x, valor)
  }
  tiempo1 <- proc.time()-tiempo
  print(tiempo1)
  return(x)
  
}

simula_vida(0, tabla, 10000)
####################################################################################################################
simula_vida <- function( edad, tabla )
{
  muestras <- rep(1, nrow(tabla)-edad )
  for ( i in 1:length(muestras) )
  {
    qx <- tabla[edad+i,2]
    muestras[i] <- sample(c(0,1),1,replace = F, prob = c( qx,1-qx ) )
  }
  return(edad-1 + (1:length(muestras))[muestras==0][1]  )
}

simula_vida(0, tabla)
####################################################################################
simular_vidas <- function(edad, tabla, n){
  tiempo <-proc.time()
  x <- vector(mode = "numeric", length = n)
  for(i in x){
    x[i] = simula_vida(edad, tabla)
  }
  tiempo1 <- proc.time()-tiempo
  print(tiempo1)
  return(x)
  
}

simular_vidas(0, tabla, 10)



if(edad-1 + (1:length(muestras))[muestras==0][1] > tiempo_cobertura){
  append(x, 1)
}
else{
  append(x, 0)
}



simula_vida <- function( edad, tabla, tiempo_cobertura, n){
  print("entreee")
  vidas1 <- c(1:n)
  print("bbbb")
  x <- vector()
  
  for(i in vidas1){
    
    muestras <- rep(1, nrow(tabla)-edad )
    
    for ( i in 1:length(muestras) ){
      qx <- tabla[edad+i,2]
      muestras[i] <- sample(c(0,1),1,replace = F, prob = c( qx,1-qx ) )
    }
    
  }
  return("gg")
  
}

simular_vidas <- 
  
  
  
  simula_vida <- function( edad, tabla )
  {
    tiempo <-proc.time()
    muestras <- rep(1, nrow(tabla)-edad )
    for ( i in 1:length(muestras) )
    {
      qx <- tabla[edad+i,2]
      muestras[i] <- sample(c(0,1),1,replace = F, prob = c( qx,1-qx ) )
    }
    v <- edad-1 + (1:length(muestras))[muestras==0][1]
    tiempo1 <- proc.time()-tiempo
    #print(tiempo1)
    return(v)
  }

simular_vidas <- function(edad, tabla, n,k){
  tiempo <-proc.time()
  x <-  vector(mode = "numeric", length = n)
  for(i in 1:n){
    x[i] <- simula_vida(edad, tabla)
    
  }
  
  tiempo1 <- proc.time()-tiempo
  print(tiempo1)
  return(x)
  
}

determina_k <- function(vector){
  
}
x <- range(1,10)
simular_vidas(0, tabla, 21)
simula_vida(0, tabla)
