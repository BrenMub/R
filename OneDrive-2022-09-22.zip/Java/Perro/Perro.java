import javax.swing.JOptionPane;


public class Perro{
	private String nombre; 
	private String estado; 

	public Perro(String nombre, String estado){
		this.nombre=nombre; 
		this.estado= estado;
	}
	public Perro(String nombre){
		this.nombre=nombre; 
		sentarse();

	}
	public Perro(){
		this.nombre="";
		this.estado="";
	}





	public void bautizar(String nombre){
		this.nombre=nombre; 
	}

	public void correr(){
		String correr = "              .--~~,__\n"+ 
	    " :-....,-------`~~'._.'\n"+ 
	    "  `-,,,  ,_      ;'~U'\n"+ 
	    "   _,-' ,'`-__; '--.\n"+ 
	    "  (_/'~~      ''''(;\n";
	    this.estado= "corriendo\n"+ correr;

	}

	public void sentarse(){
		String sentado= "                                           /\\ /\\\n";
      	sentado += "                                          /  \\---._\n";
      	sentado += "                                         / / `     `\\\n";
      	sentado += "                                         \\ \\   `'<@)@)      \n";
      	sentado += "                                         /`         ~ ~._ \n";
      	sentado += "                                        /                `() \n";
      	sentado += "                                       /    \\   (` ,_.:.  /\n";
      	sentado += "                                      / ~    `\\   (vVvvvvV\n";
      	sentado += "                                     /       |`\\_ `^^^/\n";
      	sentado += "                                 ___/________|_  `---'\n";
      	sentado += "                                (______________) _\n";
      	sentado += "                                _/~          | `(_)\n";
      	sentado += "                              _/~             \\  \n";
      	sentado += "                            _/~               |\n";
      	sentado += "                          _/~                 |\n";
      	sentado += "                        _/~                   |\n";
      	sentado += "                      _/~         ~.          |\n";
      	sentado += "                    _/~             \\        /\\\n";
      	sentado += "                 __/~               /`\\     `||\n";
      	sentado += "               _/~      ~~-._     /~   \\     ||\n";
      	sentado += "              /~             ~./~'      \\    |)\n";
      	sentado += "             /                 ~.        \\   )|\n";
      	sentado += "            /                    :       |   ||\n";
      	sentado += "            |                    :       |   ||\n";
      	sentado += "            |                   .'       |   ||\n";
      	sentado += "       __.-`                __.'--.      |   |`---. \n";
      	sentado += "    .-~  ___.         __.--~`--.))))     |   `---.)))\n";
     	sentado += "   `---~~     `-...--.________)))))      \\_____)))))\n"; 

     	this.estado= "sentado\n"+ sentado;
	}

	public String getEstado(){
		return this.estado;
	}


	public String saludar(){
		String saludo= " ";
		saludo= saludo + "Hola me llamo " + nombre;
		saludo += " y estoy ";
		saludo= saludo + estado;
		return saludo;  

	}

	public static void main (String [] args){
		Perro perro1 = new Perro();
		perro1.bautizar("Figo");
		perro1.correr();
		String saludoPerro1 = perro1.saludar();
		System.out.println(saludoPerro1); 
		

		Interfaz interfaz = new Interfaz();
		String nombrePerro = interfaz.solicitarUnaHilera("Digite el nombre de su perro");
		Perro perro2= new Perro(nombrePerro);
		System.out.println(perro2.saludar());
	}
		




	}
	
		







	
