public class PruebaPerro{




	public static void main (String [] args){
		// NombreDeLaClase nombreInstancia = new NombreDeLaClase();
		Perro perro1 = new Perro();
		// nombreInstancia.nombreMetodo(parametros)
		perro1.bautizar("Milu");
		perro1.correr();
		String saludoPerro1 = perro1.saludar();
		System.out.println(saludoPerro1); }

}

public static void main (String [] args){
	Perro perro1= new Perro
	perro1.bautizar("Figo");
	perro1.correr();
	String saludoPerro1= perro1.saludar();
	System.out.println(saludoPerro1); 
}


