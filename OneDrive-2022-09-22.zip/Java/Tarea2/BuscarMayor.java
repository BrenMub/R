public class BuscarMayor{
	public double buscarMayor(double a, double b, double c, double d, double e){
		double mayor= a;
		if(a> b){
			mayor=a;

		} 
		else{
			mayor= b;
		}
		if(mayor> c){
			mayor= mayor;


		}
		else{
			mayor=c;
		}

		if(mayor> d){
			mayor=mayor;
		}
		else{
			mayor=d;
		}

		if(mayor>e){
			mayor=mayor;
		}
		else{
			mayor=e;
		}
		return mayor;



		}
	public static void main(String []args){
		BuscarMayor buscarMayor= new BuscarMayor();
		Interfaz interfaz= new Interfaz(); 

		double numero1= interfaz.solicitarNumeroReal("Digite el primer numero");
		double numero2= interfaz.solicitarNumeroReal("Digite el segundo numero");
		double numero3= interfaz.solicitarNumeroReal("Digite el tercer numero");
		double numero4= interfaz.solicitarNumeroReal("Digite el cuarto numero");
		double numero5= interfaz.solicitarNumeroReal("Digite el quinto numero");

		double valorMayor= buscarMayor.buscarMayor(numero1, numero2, numero3, numero4, numero5);
		System.out.println("Los numeros ingresados respectivamente son: " + numero1 + "," + numero2 +"," + numero3 + "," + numero4 + "," + numero5);
		System.out.println("El numero mayor es: " + valorMayor);



	}
	
}