public class Bisiesto{
	
	public boolean esMultiploDe4(int numero){
		boolean esCorrecto= false; 
		if(numero%4==0){
			esCorrecto= true;

		}
		return esCorrecto;

	}
	public boolean noEsMultiploDe100(int numero1){
		boolean esCorrecto1= false;
		int resultado1= numero1%100;
		if(resultado1!=0){
			esCorrecto1=true;

		}
		return esCorrecto1;
	}
	public boolean esMultiploDe400(int numero2){
		boolean esCorrecto2= false;
		int resultado2= numero2%400;
		if(resultado2==0){
			esCorrecto2= true;
		}
		return esCorrecto2;
	}

	public static void main(String [] args){
		Bisiesto bisiesto= new Bisiesto();
		Interfaz interfaz = new Interfaz(); 

		int year= interfaz.solicitarNumeroEntero("Digite un a\u00f1o");
		boolean esValido= bisiesto.esMultiploDe4(year);
		if(esValido){

			boolean esValido2= (bisiesto.noEsMultiploDe100(year)) ^ (bisiesto.esMultiploDe400(year));
			if(esValido2){
				if(year==0){

				}else{ 
					System.out.println("El año " + year+ " es bisiesto");
				}


			}
			else{
				System.out.println("El año "+ year +" no es bisiesto");
			}

		}
		else{
			System.out.println("El año "+ year +" no es bisiesto");
		}


	}




}


	





