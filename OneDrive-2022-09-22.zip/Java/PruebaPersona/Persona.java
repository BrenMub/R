public class Persona{
	private String nombre; 
	private int edad; 

	public void bautizar(String nombreParametro, int edadParametro){
		nombre= nombreParametro; 
		edad= edadParametro; 

	}

	public void saludar(){
		String datosDeLaPersona = "Hola me llamo " + nombre +" y tengo " + edad + " años"; 
		System.out.println(datosDeLaPersona);

		}


}


