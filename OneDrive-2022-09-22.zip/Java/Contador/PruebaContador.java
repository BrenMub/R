public class PruebaContador{
	
	public static void main (String [] args){
		Contador contador1 = new Contador ();
		contador1.mostrarDatos();
		contador1.aumentar(); // 1
		contador1.mostrarDatos();  // 1


		contador1.duplicar(); 
		contador1.mostrarDatos(); 

		contador1.disminuirEn(1); 
		contador1.mostrarDatos(); 

	
	}


}