import javax.swing.JOptionPane;

public class PruebaTriangulo1{

	public static void main(String [] args){
		Triangulo1 triangulo1= new Triangulo1(3,4,5 );
		triangulo1.getPerimetro();
		triangulo1.getSemiperimetro();
		triangulo1.showArea(); 


		Triangulo1 triangulo2 = new Triangulo1(5,12,13);
		triangulo2.showArea();

		double sumaAreas= triangulo1.getArea()+triangulo2.getArea();

		System.out.println("La suma de las areas es " +sumaAreas );


		Triangulo1 triangulo3= new Triangulo1();
		Interfaz interfaz = new Interfaz (); 

		int lado1= interfaz.solicitarNumeroEntero("Digite el lado1");
		int lado2= interfaz.solicitarNumeroEntero("Digite el lado2"); 
		int lado3= interfaz.solicitarNumeroEntero("Digite el lado3");

		int resultado= triangulo3.averiguarPerimetro1(lado1, lado2, lado3);
		System.out.println(resultado);
		JOptionPane.showMessageDialog( null, "El perimetro es: " + resultado, "Resultado", JOptionPane.WARNING_MESSAGE);

		
		


	}


}