import java.util.*;
	

public class Triangulo1{

	private int lado1;
	private int lado2;
	private int lado3;
	private double perimetro;
	private double semiperimetro;
	private double area;
	

	public Triangulo1(int a, int b, int c){
		lado1=a; 
		lado2=b;
		lado3=c;
		averiguarPerimetro();
		averiguarSemiperimetro();
		averiguarArea();
	}
 	
 	public Triangulo1(){
 		this.lado1=lado1;
 		this.lado2=lado2;
 		this.lado3=lado3;
 	}

 	public int averiguarPerimetro1(int lado1, int lado2, int lado3){
 		return lado1+ lado2+ lado3;
 	}


	public void averiguarPerimetro(){
		perimetro= lado1+lado2+lado3;

	}
	public void getPerimetro(){
		System.out.println("Perimetro:" + perimetro);
	}
	public void averiguarSemiperimetro(){
		semiperimetro= perimetro/2;

	}
	public void getSemiperimetro(){
		System.out.println("Semiperimetro: " + semiperimetro);
	}

	public void averiguarArea(){
		area= Math.sqrt(semiperimetro*(semiperimetro- lado1)*(semiperimetro-lado2)*(semiperimetro-lado3));

	}

	public void showArea(){
		System.out.println("El area es:"+ area); 
	}


	public double getArea(){
		return area; 
	}


	public void getlado1(){
		System.out.println("lado1= " + lado1);
	}

}