public class Compuestos{
	private char elemento; 


	public Compuestos( char elemento){
		this.elemento=elemento;

	}



	public String retornarDatos(){
		String datos= "El elemento es: " + elemento;
		return datos; 
	}
}