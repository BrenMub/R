public class Calculadora{

	public int multiplicar(int numero1, int numero2){
	 
		return numero1*numero2;
	} 
	public double sumar(double numero3, double numero4){

		return numero3+numero4; 
	}
	public double restar(double numero5, double numero6){

		return numero5-numero6;
	}
	public double dividir(double numero7, double numero8){

		return numero7/numero8;
	}
	public double elevar(double base, double exponente){
		int n =1;
		double resultado=1;
		while(n<=exponente){
			resultado=resultado*base;
			n++;


		}
			return resultado;

	}
	public int factorial(int denominador){
		int n =1; 
		int resultado=1;
		while(n<=denominador){
			resultado=resultado*n;
			n++;
		}
		return resultado;
	}
	public double sen(double x, int n){
		int contador=1;
		double  resultado=0;
		int signo=1;
		if(n%2==0){
			n++;
		}
		while(contador<= n){
			double numerador= elevar(x,contador);
			int denominador= factorial(contador);
			double fraccion= numerador/denominador *signo;
			resultado= resultado+ fraccion;
			signo=signo*-1;
			contador= contador+2;
		}
		return resultado;
	}
	public int contarDigitos(int numero){
		int contador= 0;
		while(numero!=0){
			numero= numero/10;
			contador++;
		}
		return contador; 
	}
	public boolean averiguarArmstrong(int numero){
		int exponente= contarDigitos(numero);
		int contador= 0;
		int resultado=0;
		int numeroTemporal=numero;
		while(numeroTemporal!=0){
			int digito= numeroTemporal%10;
			resultado+= elevar(digito, exponente);
			contador++;
			numeroTemporal=numeroTemporal/10;

		} 
		return resultado==numero;
		
	}
	public void imprimirNumerosArmstrong(int numero){
		for(int i=1;i<=numero;i++ ){
			if(averiguarArmstrong(i)){
				System.out.println(i);
			}

		}
		

	}
	public int calcularProductoria(int n, int m){
		int resultado=1;
		for(int i= n; i<=m;i++){
			resultado= resultado*i;

		}
		return resultado;
	}

	

}