import javax.swing.JOptionPane;

public class PruebaCalculadora{
	public static void main (String [] args){

		Calculadora calculadora1 = new Calculadora();
		Interfaz interfaz = new Interfaz ();

		int numero1 = interfaz.solicitarNumeroEntero("Digite el primer numero");
		int numero2 = interfaz.solicitarNumeroEntero("Digite el segundo numero");
	
		int resultado = calculadora1.multiplicar(numero1,numero2);
		System.out.println(resultado);
		JOptionPane.showMessageDialog(null, "El resultado es : " + resultado, "Resultado", JOptionPane.INFORMATION_MESSAGE);
		


		Calculadora calculadora2 = new Calculadora(); 
	    Interfaz1 interfaz1 = new Interfaz1(); 

	    double numero3 = interfaz1.solicitarNumeroReal("Digite el tercer numero");
		double numero4 = interfaz1.solicitarNumeroReal("Digite el cuarto numero");
	
		double resultado1 = calculadora2.sumar(numero3,numero4);
		System.out.println(resultado1);
		JOptionPane.showMessageDialog( null,"El resultado es: " + resultado1, "Resultado", JOptionPane.INFORMATION_MESSAGE);



		Calculadora calculadora3 = new Calculadora(); 
	    Interfaz1 interfaz2 = new Interfaz1(); 

	    double numero5 = interfaz1.solicitarNumeroReal("Digite el quinto numero");
		double numero6 = interfaz1.solicitarNumeroReal("Digite el sexto numero");
	
		double resultado2 = calculadora3.restar(numero5,numero6);
		System.out.println(resultado2);
		JOptionPane.showMessageDialog( null,"El resultado es: " + resultado2, "Resultado", JOptionPane.INFORMATION_MESSAGE);


		Calculadora calculadora4 = new Calculadora(); 
	    Interfaz1 interfaz3 = new Interfaz1(); 

	    double numero7 = interfaz1.solicitarNumeroReal("Digite el septimo numero");
		double numero8 = interfaz1.solicitarNumeroReal("Digite el octavo numero");
	
		double resultado3 = calculadora4.dividir(numero7,numero8);
		System.out.println(resultado3);
		JOptionPane.showMessageDialog( null,"El resultado es: " + resultado3, "Resultado", JOptionPane.INFORMATION_MESSAGE);


	    }

	

 }