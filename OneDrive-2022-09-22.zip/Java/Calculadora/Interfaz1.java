import javax.swing.JOptionPane;


public class Interfaz1 {
	
	public double solicitarNumeroReal(String titulo){
		String numeroHilera = JOptionPane.showInputDialog(titulo);
		double numero = 0.0;
		try{
			 numero = Double.parseDouble (numeroHilera);
		}
		catch(Exception e){
			System.err.println("El valor digitado no es un número");
			JOptionPane.showMessageDialog(
				null, 
				"El valor digitado no es un n\u00FAmero", 
				"Error", 
				JOptionPane.ERROR_MESSAGE);
		}
		return numero;
	} 



}
