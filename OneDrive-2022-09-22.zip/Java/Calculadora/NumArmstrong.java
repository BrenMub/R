public class NumArmstrong{

	public static void main(String [] args){
		Calculadora calculadora = new Calculadora();
		Interfaz interfaz= new Interfaz();

		/*int numero1= interfaz.solicitarNumeroEntero("Digite un numero");
		System.out.println(calculadora.averiguarArmstrong(numero1));*/
		calculadora.imprimirNumerosArmstrong(200);

	}
	
}