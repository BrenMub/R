public class SerieTaylor{
	
	public static void main(String [] args){
		Calculadora calculadora= new Calculadora();
		Interfaz interfaz= new Interfaz();

		double numero1= interfaz.solicitarNumeroReal("Digite el valor de x");
		int numero2= interfaz.solicitarNumeroEntero("Digite el valor de n");


		double sen= calculadora.sen(numero1, numero2);
		System.out.println(sen);
	}
}