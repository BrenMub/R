public class SentimientosBren{
	private String sentimiento; 

	public void escribir(String sentimientoParametro){
		 sentimiento= sentimientoParametro; 

	}

	public void expresar(){
		String mensajeParaJoshua= "Hola mi amor te " + sentimiento; 
		System.out.println(mensajeParaJoshua); 
	}
}
