public class PruebaSentimientosBren{


	public static void main(String[] args ){
	SentimientosBren sentimientosBren1= new SentimientosBren(); 
	sentimientosBren1. escribir ("amo "); 
	sentimientosBren1. expresar(); 


	SentimientosBren sentimientosBren2= new SentimientosBren(); 
	sentimientosBren2. escribir("quiero abrazar");
	sentimientosBren2. expresar(); 

	SentimientosBren sentimientosBren3= new SentimientosBren(); 
	sentimientosBren3. escribir("quiero besar");
	sentimientosBren3. expresar(); 





	}
	

}