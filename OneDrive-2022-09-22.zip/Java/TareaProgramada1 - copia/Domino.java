public class Domino{

	private Ficha [] fichas;

	public Domino(){
		fichas = new Ficha [28]; 
		int contador=0;
		for(int i=0; i<=6; i++){ 
			for(int j=i; j<=6;j++){
				Ficha ficha = new Ficha(i,j);
				fichas[contador]=ficha;
				contador++;
				
			}
			
			
			
		}

	}

	public void imprimirFichas(){
		for(int i=0; i<fichas.length;i++){
			System.out.println(fichas[i].retornarDatos());
		}
	}

	public static void main(String []args){
		Domino fichas= new Domino();
		fichas.imprimirFichas();
	}


	
}