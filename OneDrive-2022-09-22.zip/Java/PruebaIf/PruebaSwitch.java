public class PruebaSwitch{
	public static void main(String [] args){
		Interfaz interfaz = new Interfaz();
		Calculadora calculadora= new Calculadora(); 


		String opciones= "Digite una opcion: \n 1-Convertir de kg a lbs \n 2-Convertir de cm plg";
		int valor = interfaz.solicitarNumeroEntero(opciones);

		switch(valor){
			case 1:
				double kg= (double) (interfaz.solicitarNumeroEntero("Digite la cantidad de kg"));
				double lb= calculadora.convertirDeKgALb(kg);
				System.out.println("Resultado: "+ kg + "kilogramos son "+ lb + " libras");
				
			break;
			case 2: 
				double cm= (double)(interfaz.solicitarNumeroEntero("Digite la cantidad de cm"));
				double plg= calculadora.convertirDeCmAPlg(cm);
				System.out.println("Resultado: "+ cm +" centimetros son " + plg+ " pulgadas");
			break;
			default: 
					System.out.println("Opcion invalida");





		}

	} 
	
}