public class Calculadora{

	public int multiplicar(int numero1, int numero2){
	 
		return numero1*numero2;
	} 
	public double sumar(double numero3, double numero4){

		return numero3+numero4; 
	}
	public double restar(double numero5, double numero6){

		return numero5-numero6;
	}
	public double dividir(double numero7, double numero8){

		return numero7/numero8;
	}
	public double convertirDeCmAPlg(double cm){
		return cm/2.54;
	}
	public double convertirDeKgALb(double kg){
		double lb=kg*2.204623;
		return lb; 
	}

}