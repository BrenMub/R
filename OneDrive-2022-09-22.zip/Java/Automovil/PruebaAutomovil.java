public class PruebaAutomovil{

	public static void main(String [] args){
		Automovil automovil1= new Automovil(0,6,3);
		automovil1.acelerar();
		automovil1.acelerar(2,1);
		automovil1.frenar();
		automovil1.mostrarDatos();




	}
	
}