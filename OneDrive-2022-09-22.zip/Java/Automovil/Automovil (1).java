public class Automovil {
	
	private int aceleracion;
	
	private double velocidadActual;

	private String estado;

	private int marchaActual;


	public void Automovil(String estado, double aceleracion, double velocidad, int marcha){
		this.estado= estado;
		this.aceleracion= 0;
		velocidadActual=velocidad;
		marchaActual= marcha;

	}

	


	// Metodos
	public void encender(){
		estado = encendido;
	}

	public void apagar(){
		estado = apagado;
	}

	public void cambiarMarcha(int marcha){
		marchaActual = marcha;

	}


	public void acelerar(){
		velocidadActual =+ 12;

	}

	public void frenar(){
		velocidadActual =- 8*0.875;

	}

	public void acelerar(double aceleracion, double tiempo ){
		velocidad =+ aceleracion*tiempo
	}






}