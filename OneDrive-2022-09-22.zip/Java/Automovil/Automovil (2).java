public class Automovil {
	
	private double aceleracion;
	
	private double velocidadActual;

	private String estado;

	private int marchaActual;


	public Automovil(  double aceleracion, double velocidad, int marcha){
		this.aceleracion= 0;
		velocidadActual=velocidad;
		marchaActual= marcha;

	}

	// Metodos
	public void encender(){
		estado = "encendido";
	}

	public void apagar(){
		this.estado = "apagado";
	}

	public void cambiarMarcha(int marcha){
		marchaActual = marcha;

	}


	public void acelerar(){
		velocidadActual = velocidadActual + 12;

	}

	public void frenar(){
		velocidadActual = velocidadActual - 8*0.875;

	}

	public void acelerar(double aceleracion, double tiempo ){
		velocidadActual = velocidadActual + aceleracion*tiempo;
	}

	public void mostrarDatos(){
		System.out.println("El carro esta "+ velocidadActual );
	} 




}