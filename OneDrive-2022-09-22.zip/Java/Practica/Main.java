public class Main{
	private Conjunto conjunto; 



	public Conjunto union(Curso [] curso){
		Curso union [] = new Curso[100]; 
		int i=0;
		while(i<cursos.length ){
			union[i]=cursos[i];
			i++;
			System.out.println(i);
		}
		for(int j=0; j<union.length;j++){
			for(int f=0; f<curso.length; f++ ){
				if(union[j]!= null && curso[f]!=null){
					if(union[j].getSigla()!= curso[f].getSigla()){
					union[cursos.length]=curso[f];
				}

				}
				

			}
			


		}
	
		 return union;



	}
	public Curso [] interseccion(Curso [] curso){
		Curso interseccion []= new Curso[100];
		int contador=0;
		for(int i=0; i<2; i++ ){
			for(int j=0; j<2; j++){
				if(cursos[i].getSigla()!=null && curso[j].getSigla()!=null){
					if(cursos[i].getSigla()== curso[j].getSigla()){
					interseccion[contador]=cursos[i];
					contador++;
				}

				}
				
			}
		}
		return interseccion;
	}
	
public static void main(String []args){
		Conjunto conjunto= new Conjunto(5);
		Conjunto conjunto2= new Conjunto(5);
		Curso curso1= new Curso("ma0250","ugalde", 34);
		Curso curso2= new Curso("ma150", "Samy", 4);
		Curso curso3= new Curso("ma1001", "Cambronero", 3);
		//Curso[] cursos=conjunto.crearConjunto(curso1, curso2);
		conjunto.agregarCurso(curso1);
		conjunto.agregarCurso(curso2);
		conjunto2.agregarCurso(curso2);
		conjunto2.agregarCurso(curso3);

		conjunto.imprimirConjunto();
		conjunto2.imprimirConjunto();
		Curso [] union= conjunto.union(conjunto2.getConjunto());
		Curso [] interseccion= conjunto.interseccion(conjunto2.getConjunto());
		


		conjunto.imprimir(interseccion);
		conjunto.imprimir(union);
	
		//System.out.println(cursos[0].getSigla());

		//Curso [][] curso2={{ma0250}, {calculoEnUnaVariable}, {4}};
		//Curso [][] curso3= {{ma0350}, {calculo2}, {4}};
		//Curso [][] curso4= {{ma1201}, {calculo1}, {3}};
		//Curso [][] curso5={{ma1003}, {calculo3}, {3}};
		//Curso [][] curso6={{ma1005}, {ecuacionesDiferenciales}, {3}};


	} 







}