public class ValorMayor{

	public int retornarMayor(int [][] matriz){
		int mayor= matriz[0][0];
		for(int f=0; f<matriz.length; f++){
			for(int c=0; c<matriz[f].length; c++){
				if(mayor< matriz[f][c]){
					mayor=matriz[f][c];
				}
			}
		}
		return mayor;

	}
	public void imprimirMatriz(int [][] matriz){
		for(int f=0; f<matriz.length; f++){
			for(int c=0; c<matriz[f].length;c++){
				System.out.print(matriz[f][c] + " ");
			}
			System.out.println();
		}
		
	}




	public static void main(String []args){
		ValorMayor mayor= new ValorMayor();
		int [][] matrizA={{1,3,7,70}, {56,7,9,2,9000}};
		System.out.println(mayor.retornarMayor(matrizA));
	}
	





















	
}import javax.swing.JOptionPane;

public class Interfaz {

	public String solicitarUnaHilera(String titulo){
		String hilera = JOptionPane.showInputDialog(titulo);
		return hilera;
	}

	public void mostrarMensaje(String contenido){
		JOptionPane.showMessageDialog(null, contenido );
	}
	
	public int solicitarNumeroEntero(String titulo){
		int numero = 0;
		boolean esValido = true;
		do{
			String numeroHilera = JOptionPane.showInputDialog(titulo);
			try{
				numero = Integer.parseInt(numeroHilera);
				esValido = true;
			}
			catch(NumberFormatException e){
				esValido = false;
				System.err.println("El valor digitado no es un número");
				JOptionPane.showMessageDialog(
					null, 
					"El valor digitado no es un n\u00FAmero", 
					"Error", 
					JOptionPane.ERROR_MESSAGE);
			}
		}while(!esValido);
		return numero;
	}

	public double solicitarNumeroReal(String titulo){
		
		double numero = 0;
		boolean esValido = true;
		do{
			String numeroHilera = JOptionPane.showInputDialog(titulo);
			try{
				numero = Double.parseDouble(numeroHilera);
				esValido = true;
			}
			catch(NumberFormatException e){
				esValido = false;
				System.err.println("El valor digitado no es un número");
				JOptionPane.showMessageDialog(
					null, 
					"El valor digitado no es un n\u00FAmero", 
					"Error", 
					JOptionPane.ERROR_MESSAGE);
			}
		}while(!esValido);
		return numero;
	}

}