public class MatrizIdentidad{


	public boolean verificarRectangular(int [][] matriz){
		boolean esRectangular=true;
		int tamano= matriz[0].length;
		System.out.println(matriz[1].length);
		System.out.println(matriz.length);
		for(int i=0; i<matriz.length; i++){
			if(tamano!=matriz[i].length){
				
				esRectangular=false; 
				

			}



		}
		return esRectangular;

	}
	public boolean esRectangular(int [][] matriz){
		boolean resultado = true;
		int tam = matriz[0].length;
		for (int f = 0; f < matriz.length; f++){
			if(tam != matriz[f].length){
				resultado = false;
			}
		}
		return resultado;

	}
	public int getFila(int[][] matriz){
		int cantidadFilas= matriz.length;
		return cantidadFilas;

	}
	public int [][] obtenerIdentidad(int [][] matriz){
		int fila=getFila(matriz);
		int [][] identidad= new int [fila][fila];

		if(verificarRectangular(matriz)==true){
			for(int f=0; f<matriz.length; f++){
				System.out.println(matriz.length);
				for(int c=0; c<matriz.length; c++){
					if(f==c){
						identidad[f][f]=1;
					}
					
				}
			}
		}
		return identidad; 

	}
	public void imprimirMatriz(int [][] matriz){
		for (int f = 0 ; f < matriz.length; f++){
			for (int c = 0 ; c < matriz[f].length ; c++){
				System.out.print(matriz[f][c] + " ");
			}
			System.out.println();
		}
	}
	






	public static void main(String []args){
		MatrizIdentidad identidad=new MatrizIdentidad();
		int [][] matriz={{1,3}, {1,6}};
		System.out.println(identidad.esRectangular(matriz));
		System.out.println(identidad.verificarRectangular(matriz));
		System.out.println(identidad.getFila(matriz));
		int [][] identidad1= identidad.obtenerIdentidad(matriz);
		identidad.imprimirMatriz(identidad1);


	}
}