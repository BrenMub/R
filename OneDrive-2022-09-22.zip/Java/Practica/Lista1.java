public class Lista1{

	public int [] devolverArreglo(int [] arreglo){
		int array []= new int [arreglo.length];
		for(int i=0; i<arreglo.length; i++){
			boolean repetido= false;
			for(int j= 0; j< array.length; j++){
				if(arreglo[i]== array[j]){
					repetido=true;
				}	

			}
				if(repetido==false){
					int j=0;
					while(array[j]!=0){
						j++;

					}
					array[j]=arreglo[i];
				}

		}
		return array;
	}
	public int cantidadDeNumerosNoCero(int [] arreglo){
		int contador=0;
		for(int i=0; i<arreglo.length; i++){
			if(arreglo[i]!=0){
				contador++;

			}
		}
		return contador;

	}
	
	public boolean tieneCero(int [] arreglo){
		boolean hayCero= false;
		for(int i=0; i<arreglo.length; i++){
			
			if(arreglo[i]==0){
				hayCero=true; 

			}
		}
		return hayCero;

	}
	public int [] devolverArregloFinal(int [] array, int [] arreglo){
		if(tieneCero(arreglo)==true){
			int array2 []= new int [cantidadDeNumerosNoCero(array)+1];
			int contador=0;
			int contador1=0;
			int i=0;
			int j=0;
			while(contador<array2.length  && contador1<array2.length ){
				array2[i]= array[j];
				contador++;
				contador1++;
				i++;
				j++;

			}
			return array2;
		}
		else{
			int array2 []= new int [cantidadDeNumerosNoCero(array)];
			int contador=0;
			int contador1=0;
			int i=0;
			int j=0;
			while(contador<array2.length  && contador1<array2.length ){
				array2[i]= array[j];
				contador++;
				contador1++;
				i++;
				j++;

			}
			return array2;

		}


	}

	
	
	/*public int[] devolverArregloFinal(int[] arreglo, int [] array){
			int array2 []= new int [array.length - cantidadRepetidos(arreglo)];
			int contador=0;
			int contador1=0;
			int i=0;
			int j=0;
			while(contador< array.length - cantidadRepetidos(arreglo) && contador1< array.length - cantidadRepetidos(arreglo) ){
				array2[i]= array[j];
				contador++;
				contador1++;
				i++;
				j++;
			}
			return array2;
			
		
	}*/
	public void imprimir(int [] arreglo){ //Este método me imprime todas las fichas del jugador1
			for(int i=0; i< arreglo.length;i++){
				System.out.println(arreglo[i]);

			}	
		
	}


	public static void main(String []args){
		int [] arreglo= {1,2,1,1,5,8,8,6,1,9,98};
		Lista1 lista1= new Lista1();
		int []array=  lista1.devolverArreglo(arreglo);
		int [] array2= lista1.devolverArregloFinal(array, arreglo);
		lista1.imprimir(array);
		System.out.println(".................");

		//lista1.imprimir(array2);
		//System.out.println(array[3]);
		//System.out.println(lista1.cantidadDeNumerosNoCero(array));
		//System.out.println(lista1.tieneCero(arreglo));
		lista1.imprimir(array2);
		
		


	}
}