public class Vacunacion{
	private int [] centralNorte;
	private int [] centralSur;
	private int [] huetarNorte;
	private int [] pacificoCentral;
	private int [] huetarAtlantica;
	private int [] brunca;
	private int [] chorotega;
	private int [][] datosVacunacion;

	public Vacunacion(){
		centralNorte = new int[]{94409, 124763,144345, 171062, 197544, 227468, 261465, 299498};
		centralSur= new int[]{173116, 222953, 253205, 299030, 349709, 400385, 456888, 518432 };
		huetarNorte=new int[]{17519, 23330, 28254, 36045, 42028, 49001, 57656, 66153};
		pacificoCentral=new int[]{27818, 36882,44327, 51207, 57488, 65240, 72511, 80612};
		huetarAtlantica=new int[]{17964, 23398,29895,37677, 49275, 62316, 74389, 87545};
		brunca=new int[]{20969, 28337, 33876, 41640, 52965, 65046, 75222, 89188};
		chorotega=new int[]{32560, 45267, 52897, 61666, 69875, 80796, 95800, 110472};
		datosVacunacion= new int[][]{centralNorte, centralSur, huetarNorte, pacificoCentral, huetarAtlantica, brunca, chorotega};

	}
	public int [][] calcularVacunacionSemanal(){
		int [][] vacunacionSemanal= new int [2][8];
			for(int i=0; i<8; i++){
				vacunacionSemanal[0][i]=i+12;
			}

			for(int c=0; c<8; c++ ){
				for(int f= 0; f< 7; f++){
					//System.out.print(datosVacunacion[f][c]+" ");
				vacunacionSemanal[1][c]= vacunacionSemanal[1][c] + this.datosVacunacion[f][c];

				}
				
			
			}
		
		return vacunacionSemanal;
		
	}
	
		
	
	public void imprimirMatriz(int [][] matriz){
		for(int i=0; i< matriz.length; i++){
			for(int j=0; j<matriz[i].length; j++){
				System.out.print(matriz[i][j]+ " " );
			}
			System.out.println();
			

		}
		

	}
	public void imprimirIndividualemente(int [][]vacunacionSemanal, int semana){
		System.out.println(vacunacionSemanal[semana-12][1]);
	}
	public int calcularCantidadVacunasAplicadas(int [][] matriz, int semana){
		int resultado=0;
		resultado=matriz[1][semana-12]-matriz[1][(semana-1)-12];
		return resultado;

	}

	public static void main(String []args){
		Vacunacion vacunacion= new Vacunacion();
		int [][] vacunacionSemanal= vacunacion.calcularVacunacionSemanal();
		vacunacion.imprimirMatriz(vacunacionSemanal);
		vacunacion.imprimirIndividualemente(vacunacionSemanal,13);
		//System.out.println(vacunacion.calcularVacunacionSemanal(datosVacunacion));
		System.out.println(vacunacion.calcularCantidadVacunasAplicadas(vacunacionSemanal, 13));
	}
	
}