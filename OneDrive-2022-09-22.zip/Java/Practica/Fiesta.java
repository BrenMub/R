public class Fiesta{
	
	
	public boolean esFinDeSemana(String dia){
		boolean esCorrecto= false;
		if(dia.equals("sabado") ^ dia.equals("domingo")){
			esCorrecto=true;

		}
		return esCorrecto;
	}

	public boolean verificarExito(int puros){
		boolean esCorrecto1= false;
		if(puros >= 40 && puros <= 60){
			esCorrecto1= true; 
		}
		return esCorrecto1;

	}
	public boolean verificarExitoEnFinDeSemana(int puros){
		boolean esCorrecto2= false;
		if(puros >= 40 ){
			esCorrecto2= true; 
		}
		return esCorrecto2;
	}


	public static void main(String [] args){
		Fiesta fiesta= new Fiesta();
		Interfaz interfaz = new Interfaz(); 

		String dia1= interfaz.solicitarUnaHilera("Digite el dia en que se realiza la fiesta");
		boolean esValido= fiesta.esFinDeSemana(dia1);
		if(esValido){
			int cantidadPuros= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumida");
			boolean tieneExito= fiesta.verificarExitoEnFinDeSemana(cantidadPuros);
			if(tieneExito){
				System.out.println("La fiesta tuvo exito");
			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}
		}
		else{
			int cantidadPuros1= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos"); 
			boolean tieneExito1= fiesta.verificarExito(cantidadPuros1);
			if(tieneExito1){
				System.out.println("La fiesta tuvo exito");
			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}

		}

	}
}