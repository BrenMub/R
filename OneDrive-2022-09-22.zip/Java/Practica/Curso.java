public class Curso{
	private String sigla;
	private String nombre;
	private int creditos;


	public Curso(String sigla, String nombre, int creditos){
		this.sigla=sigla; 
		this.nombre=nombre;
		this.creditos=creditos; 

	}

	public String getSigla(){
		return sigla;
	}
	public boolean compararCurso(Curso curso1){
		boolean esElMismo=false;
		if(sigla.equalsIgnoreCase(curso1.getSigla())){
			esElMismo = true;
		}
		return esElMismo;
	}
	public String retornarDatos(){
		String datos= sigla +"," + nombre+ "," + creditos;
		return datos;

	}






	


	
}