public class PracticaMatrices{

	public boolean esRectangular(int[][] matriz){
		boolean resultado=true; 
		int tamano= matriz[0].length; 
		for(int i=0; i< matriz.length; i++){
			if(tamano!=matriz[i].length){
				resultado=false;
			}
		}
		return resultado;

	}
	//public int[][] crearIdentidad(){

	//}
	public int getFila(int[][] matriz){
		int cantidadFilas= matriz[0].length;
		return cantidadFilas;

	}
	









	public static void main(String []args){
		PracticaMatrices matriz= new PracticaMatrices();
		int [] arreglo={1,2,3};
		int[][] matrizA = {arreglo,{4,5,6}};

	
		System.out.println(matriz.esRectangular(matrizA));
		System.out.pritln(matriz.getFila(matriz));

	}
}