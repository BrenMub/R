public class Conjunto{
	private Curso [] cursos;




	public Conjunto(int nElementos){

		cursos= new Curso [nElementos];
		//Curso curso= new Curso(ma0150,princiosDeMatematica,4);
		
		//matrizCursos= new Curso[filas][1];

	}
	public void agregarCurso(Curso curso){
		int i=0;
		while(cursos[i]!=null && i< 5){
			i++;
		}
		
		boolean yaEsta= false;
		for(int j =0; j<i; j++) {
			 yaEsta= cursos[j].compararCurso(curso);
		}
		if(cursos[i]==null && yaEsta==false ){
			cursos[i]= curso;
		}
		
		
	}

	public void imprimirConjunto(){
		for(int i=0; i< cursos.length; i++){
			if(cursos[i]!= null){
				System.out.println(cursos[i].retornarDatos());

			}
		

		}
		System.out.println();
	}
	public void imprimir(Curso [] curso){
		for(int i=0; i< curso.length; i++){
			if(curso[i]!= null){
				System.out.println(curso[i].retornarDatos());

			}
		

		}
		System.out.println();

	}
	
	



	public Curso[] getConjunto(){
		return cursos;
	}

	



	
	
}