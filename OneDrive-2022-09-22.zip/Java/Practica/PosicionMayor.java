public class PosicionMayor{

	public double retornarMayor(double [] arreglo){
		double mayor=arreglo[0];
		for(int i= 1; i<arreglo.length; i++){
			if(mayor< arreglo[i]){
				mayor=arreglo[i];
				
			}
			
		}
		return mayor;


	}
	public int retornarPosicion(double mayor, double [] arreglo){
		int posicion=0;
		for(int i=0; i<arreglo.length;i++){
			if(mayor==arreglo[i].length){
				posicion=i;

			}
		}
		return posicion;

		
	}


	











	public static void main(String []args){
		PosicionMayor mayor= new PosicionMayor();
		double [] arreglo= {10,3000,100.2,67.9,20,8888.9};
		System.out.println(mayor.retornarMayor(arreglo));
		System.out.println(mayor.retornarPosicion(mayor.retornarMayor(arreglo), arreglo));
	}
}