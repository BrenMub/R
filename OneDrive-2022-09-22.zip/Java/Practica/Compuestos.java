public class Compuestos{
	private Elementos [] compuesto1;
	private Elementos [] compuesto2;


	public Compuestos(){
		this.compuesto1= new Elementos [4];
		this.compuesto2= new Elementos [3];
	}
}