public class MatrizElementos{
	private Elementos [][] matrizElementos; 

	public MatrizElementos(int m, int n){
		matrizElementos= new Elementos [m][n]{{1,6,3},{8,9,2},{3,9,0}};

	}
	public void agregarElemento(Elementos elemento){
		boolean primeraVez=false;
		int contador=0;

		for(int i=0; i<matrizElementos.length; i++){
			for(int j=0; j<matrizElementos[i].length; j++){
				while(matrizElementos[i][j]==null && contador<1 && primeraVez==false){
					matrizElementos[i][j]=elemento;
					primeraVez=true;


				}
			}
		}
	}
	public Elementos [][] clonar(){
		Elementos copia [][]= new Elementos [matrizElementos.length][matrizElementos.length]; 
		for(int i=0; i< matrizElementos.length; i++){
			for(int j=0; j<matrizElementos[i].length; j++)
				copia[i][j]=matrizElementos[i][j];
		}
		return copia; 
	}

	public void imprimirMatriz(){
		for (int f = 0 ; f < matrizElementos.length; f++){
			for (int c = 0 ; c < matrizElementos[f].length ; c++){
				if(matrizElementos[f][c]!= null){
				System.out.print(matrizElementos[f][c].retornarDatos()+ " ");
				}
				else{
					System.out.print(" " + "  " );
				}
			
				
			}
			System.out.println( );
		}
	}
	
	public int formarCompuestos(Elementos [][] copia, Elementos []compuesto1){
		int contador=0;
		boolean sePuede= verificar(copia, compuesto1);
		System.out.println(sePuede);
		if(sePuede=true){
			for(int i=0; i<compuesto1.length; i++){
			boolean yaIngreso1=false;
				for(int f=0; f< matrizElementos.length;f++){
					for(int c=0; c< matrizElementos[f].length; c++){
						if(compuesto1[i]==matrizElementos[f][c] && yaIngreso1==false){
							matrizElementos[f][c]=null; 
						yaIngreso1=true;
						contador++;

					    }
					}
				}
			}
			sePuede=false;
			

		}
		
		return contador;
		
	}
	public void finalizar(Elementos [][] copia, Elementos [] compuesto1, Elementos [] compuesto2){
		formarCompuestos(copia, compuesto1);
		formarCompuestos(copia, compuesto2);

	}

	public boolean verificar(Elementos [][] copia, Elementos [] compuesto1 ){
		int contador=0; 
		boolean verificar=false; 
		for(int i=0; i<compuesto1.length; i++){
		boolean yaIngreso1=false;
			for(int f=0; f< copia.length;f++){
				for(int c=0; c< copia[f].length; c++){
					if(compuesto1[i]==copia[f][c] && yaIngreso1==false){
						copia[f][c]=null; 
						yaIngreso1=true;
						contador++;
					}

				}
			}
		}
		if(contador==compuesto1.length){
			verificar=true;
		}
		return verificar; 

	}

	public static void main(String []args){
		MatrizElementos matriz= new MatrizElementos(3,3);
		Elementos elemento1= new Elementos('H');
		Elementos elemento4= new Elementos('O');
		Elementos elemento5= new Elementos('N');
		Elementos [] compuesto1={elemento5, elemento1, elemento1, elemento1}; 
		Elementos [] compuesto2={elemento1, elemento1, elemento4,elemento4}; 
		//matriz.agregarElemento(elemento1);
		matriz.agregarElemento(elemento1);
		matriz.agregarElemento(elemento1);
		matriz.agregarElemento(elemento4);
		matriz.agregarElemento(elemento5);
		matriz.agregarElemento(elemento5);
		matriz.agregarElemento(elemento1);
		matriz.agregarElemento(elemento1);
		matriz.agregarElemento(elemento4);
		Elementos [][] copia= matriz.clonar(); 
		//System.out.println(matriz.formarCompuestos(copia,compuesto1, compuesto2));
		//System.out.println(matriz.formarCompuestos(copia,compuesto2));
		matriz.finalizar(copia,compuesto1, compuesto2);
		matriz.imprimirMatriz();

	}



}