public class Fiesta1{
	public static void main(String [] args){
		Interfaz interfaz= new Interfaz();
		Fiesta fiesta1 = new Fiesta(); 


		String opciones= "Digite el dia de la semana en que se realizo la fiesta \n 1-Lunes \n 2-Martes \n 3-Miercoles \n 4-jueves \n 5-viernes \n 6-sabado \n 7-Domingo";
		int valor= interfaz.solicitarNumeroEntero(opciones); 

		switch(valor){
			case 1:
			int cantidadPuros= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos en la fiesta");
			boolean esValido= fiesta1.verificarExito(cantidadPuros);
			if(esValido){
				System.out.println("La fiesta tuvo exito");
			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}
			break;
			case 2: 
			int cantidadPuros1= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos en la fiesta");
			boolean esValido1= fiesta1.verificarExito(cantidadPuros1);
			if(esValido1){
				System.out.println("La fiesta tuvo exito");
			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}
			break;
			case 3:
			int cantidadPuros3= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos en la fiesta");
			boolean esValido3= fiesta1.verificarExito(cantidadPuros3);
			if(esValido3){
				System.out.println("La fiesta tuvo exito"); 
			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}
			break;
			case 4:
			int cantidadPuros4= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos en la fiesta"); 
			boolean esValido4= fiesta1.verificarExito(cantidadPuros4);
			if(esValido4){
				System.out.println("La fiesta tuvo exito");

			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}
			break;
			case 5: 
			int cantidadPuros5= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos en la fiesta");
			boolean esValido5= fiesta1.verificarExito(cantidadPuros5);
			if(esValido5){
				System.out.println("La fiesta tuvo exito");
			}
			else{
				System.out.println("La fiesta tuvo exito");
			}
			break;
			case 6:
			int cantidadPuros6= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos en la fiesta");
			boolean esValido6= fiesta1.verificarExitoEnFinDeSemana(cantidadPuros6);
			if(esValido6){
				System.out.println("La fiesta tuvo exito");
			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}
			break;
			case 7:
			int cantidadPuros7= interfaz.solicitarNumeroEntero("Digite la cantidad de puros consumidos en la fiesta");
			boolean esValido7= fiesta1.verificarExitoEnFinDeSemana(cantidadPuros7);
			if(esValido7){
				System.out.println("La fiesta tuvo exito");
			}
			else{
				System.out.println("La fiesta no tuvo exito");
			}
			break;

		}

	}
	
}