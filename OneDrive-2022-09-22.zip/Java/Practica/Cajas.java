public class Cajas{
	private int [] caja;
	private Juguetes []juguete; 
	private int colorCaja; 


	public Cajas(){
		caja= new int [5]; 
	}


	public int obtenerNumeroCajas(){
		int numeroCajas= (int)(Math.random()*100);
		return numeroCajas;
	}
	public int cantidadJuguetes(){
		int n= obtenerNumeroCajas();
		int cantidadJuguetes= 6*n;
		return cantidadJuguetes;

	}
	public int asignarPeso(){
		int peso= (int)(Math.random()*200)+100;
		return peso; 
	}
	public int asignarColorCaja(){
		int colorCaja= (int)(Math.random()*3);
		return colorCaja; 

	}
	public int asignarColorJuguete(){   
		int colorJuguete= (int)(Math.random()*3);
		return colorJuguete; 

	}
	public Juguetes  [] crearJuguete(){
		int cantidad= cantidadJuguetes();
		juguete=new Juguetes [cantidad];
		for(int i=0; i< cantidad;i++){
				int peso= asignarPeso();
				int color=asignarColorJuguete();
				Juguetes juguete1=new Juguetes(peso, color); 
				juguete[i]= juguete1; 
				
			
		}
		
		return juguete; 
		
		
	}
	public void imprimir(Juguetes [] arreglo){
		for(int i = 0 ; i < arreglo.length ; i++){
			System.out.println(arreglo[i].retornarDatos() + " ");
		}
		System.out.println();
	}
	
	

 





	public static void main(String []args){
		Cajas caja= new Cajas();
		System.out.println(caja.obtenerNumeroCajas());
		System.out.println(caja.asignarColorCaja());
		System.out.println(caja.asignarColorJuguete());
		Juguetes [] juguete= caja.crearJuguete();
		caja.imprimir(juguete);
		



	}

}