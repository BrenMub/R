public class Juguetes{
	private int peso;
	private int colorJuguete; 

	public Juguetes(int peso, int colorJuguete){
		this.peso=peso;
		this.colorJuguete=colorJuguete;

	}

	public int getPeso(){
		return peso;
	}

	public int getColor(){
		return colorJuguete; 
	}
	public String convertirAColor(){
		String dato= "";
		switch(this.colorJuguete){
			case 0:
				dato="rojo";
			break; 
			case 1:
				dato= "verde";
			break;
			case 2: 
				dato="azul";
			break;
			
		}
		return dato;
	}
	public String retornarDatos(){
		String datos= "El juguete pesa: " + this.peso + " y su color es: " + convertirAColor();
		return datos;
	}

	
}