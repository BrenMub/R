public class Lista{


	 /*public Lista (){
		int [] arreglo = new int [31];
		for(int j=0; j<=1; j++){
			for(int i=0; i<= 30; i++){
				arreglo[j]= i;
				System.out.println(arreglo [j]);

			}
		}

	}*/

	 


	
	public int []clonar(int [] arreglo){
		int copia [] = new int [arreglo.length];
		for(int i=0; i< arreglo.length;i++){
			copia[i]= arreglo[i]; 
		}
		return copia; 


	}


	public static int[]devolverArreglo(int[] arreglo){
		int array[]=new int[arreglo.length];
		boolean haycero=false;

		for(int i=0; i<arreglo.length; i++){
			
			if(arreglo[i]==0){
				haycero=true;
			}
			boolean repetido= false;
			for(int j=0; j< array.length; j++){
				if(arreglo[i]==array[j]){
					repetido= true;
				}
			}
			if(repetido== false){
				System.out.println("here");
				int j=0;
				while(array[j]!= 0){
					j++;
				}
				array[j]= arreglo[i];	
				}
		}


		
		
		return array;
			}
	 
	




	public static void main(String [] args){
		int [] arreglo= {1,3,4,1};
		Lista lista= new Lista();
		int[] array=  devolverArreglo(arreglo);
		System.out.println(array[0]);
		

		
		
	}






}