public class Elementos{
	private char elemento; 


	public Elementos( char elemento){
		this.elemento=elemento;

	}
	public char getElemento(){
		return elemento; 
	}
	public boolean compararElemento(Elementos elemento1, Elementos elemento2){
		boolean esElMismo=false;
		if(elemento1==elemento2){
			esElMismo = true;
		}
		return esElMismo;

	}

	public String retornarDatos(){
		String datos= elemento + " ";
		return datos; 
	}
}