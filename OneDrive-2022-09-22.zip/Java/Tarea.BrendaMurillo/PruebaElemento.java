public class PruebaElemento{
	
	public static void main(String [] args){
		Elemento elemento1= new Elemento("Manganeso", "Mn", 25, 54.938045, "Gris-Blanco", 1519, 2334 );
		elemento1.setNombre();
		elemento1.setSimbolo();
		elemento1.setNumeroAtomico();
		elemento1.setMasaAtomica(); 
		elemento1.setColor(); 
		elemento1.setPuntoDeFusion();
		elemento1.setPuntoDeEbullicion();

		String nombre1= elemento1.getNombre();
		System.out.println("El nombre del elemento es: " + nombre1);

		String simbolo1= elemento1.getSimbolo();
		System.out.println("El simbolo del elemento es: " + simbolo1); 

		int numeroAtomico1= elemento1.getNumeroAtomico();
		System.out.println("El numero atomico del elemento es: " + numeroAtomico1);

		double masaAtomica1= elemento1.getMasaAtomica(); 
		System.out.println("La masa atomica del elemento es: " + masaAtomica1);

		String color1= elemento1.getColor();
		System.out.println("El color del elemento es: "+ color1);

		int puntoDeFusion1= elemento1.getPuntoDeFusion();
		System.out.println("El punto de fusion del elemento es: "+ puntoDeFusion1);

		int puntoDeEbullicion1= elemento1.getPuntoDeEbullicion(); 
		System.out.println("El punto de ebullicion del elemento es: "+ puntoDeEbullicion1 +"\n");



		Elemento elemento2 = new Elemento("Hierro", "Fe", 26, 55.845, "Gris-Plateado", 1811, 3134);
		elemento2.setNombre(); 
		elemento2.setSimbolo(); 
		elemento2.setNumeroAtomico(); 
		elemento2.setMasaAtomica();
		elemento2.setColor();
		elemento2.setPuntoDeFusion(); 
		elemento2.setPuntoDeEbullicion();

		String nombre2 = elemento2.getNombre(); 
		System.out.println("El nombre del elemento es: "+ nombre2); 

		String simbolo2 = elemento2.getSimbolo();
		System.out.println("El simbolo del elemento es: "+ simbolo2);

		int numeroAtomico2 = elemento2.getNumeroAtomico();
		System.out.println("El numero atomico del elemento es: " + numeroAtomico2); 

		double masaAtomica2 = elemento2.getMasaAtomica(); 
		System.out.println("La masa atomica del elemento es: "+ masaAtomica2); 

		String color2 = elemento2.getColor();
		System.out.println("El color del elemento es: "+ color2); 

		int puntoDeFusion2 = elemento2.getPuntoDeFusion(); 
		System.out.println("El punto de fusion del elemento es: "+ puntoDeFusion2); 

		int puntoDeEbullicion2 = elemento2.getPuntoDeEbullicion(); 
		System.out.println("El punto de ebullicion del elemento es: " + puntoDeEbullicion2);








	}

	
}