public class Elemento{

	private String nombre; 
	private String simbolo; 
	private int numeroAtomico;
	private double masaAtomica; 
	private String color; 
	private int puntoDeFusion;
	private int puntoDeEbullicion; 

	public Elemento(String nombre, String simbolo, int numeroAtomico, double masaAtomica, String color, int puntoDeFusion, int puntoDeEbullicion){
		this.nombre= nombre;
		this.simbolo= simbolo;
		this.numeroAtomico= numeroAtomico; 
		this.masaAtomica=masaAtomica; 
		this.color= color; 
		this.puntoDeFusion= puntoDeFusion; 
		this.puntoDeEbullicion= puntoDeEbullicion; 

	}
	


	public void setNombre(){
		this.nombre=nombre;
	}

	public String getNombre(){
		return nombre;

	}

	public void setSimbolo(){
		this.simbolo= simbolo;
	}
	public String getSimbolo(){
		return simbolo;

	}
	public void setNumeroAtomico(){
		this.numeroAtomico= numeroAtomico; 
	}
	public int getNumeroAtomico(){
		return numeroAtomico;

	}
	public void setMasaAtomica(){
		this.masaAtomica= masaAtomica; 
	}
	public double getMasaAtomica(){
		return masaAtomica;
	}

	public void setColor(){
		this.color= color;
	}
	public String getColor(){
		return color;
	}

	public void setPuntoDeFusion(){
		this.puntoDeFusion= puntoDeFusion;
	}
	public int getPuntoDeFusion(){
		return puntoDeFusion;
	}

	public void setPuntoDeEbullicion(){
		this.puntoDeEbullicion= puntoDeEbullicion;
	}
	public int getPuntoDeEbullicion(){
		return puntoDeEbullicion;
	}
	

	
}




