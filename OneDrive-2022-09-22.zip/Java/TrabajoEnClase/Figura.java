public class Figura{

	public void imprimirFigura(int lineaMedia){
		String asterisco= "*";
		String espacio= " ";
		for(int i=1; i<= lineaMedia; i++){
			for(int j=1; j<= i; j++){
				System.out.print(asterisco);
			}
			System.out.println(espacio);
				
			}
	}
	public void imprimirFigura1(int lineaMedia){
		for(int i= lineaMedia-1; i>=1; i--){
			for(int j=1; j<=i; j++){
				System.out.print("*");

			}
			System.out.println(" ");

		}
	}

	

	



	public static void main(String[]args){
		Figura figura= new Figura();
		figura.imprimirFigura(6);
		figura.imprimirFigura1(6);
	}
}