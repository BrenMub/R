public class Bessie{
	public int multiBessie(int numero1, int numero2){
		int resultado=0;
		int resto1=0;
		int resto2=0;
		int numeroTemporal1= numero1;
		int numeroTemporal2= numero2;

		while(numeroTemporal1!=0){
		resto1=numeroTemporal1%10;
		System.out.println(resto1);
			while(numeroTemporal2!=0){
			resto2=numeroTemporal2%10;
			System.out.println("m= "+resto2);
			resultado+= resto1*resto2;
			System.out.println("res= "+resultado);
			numeroTemporal2=numeroTemporal2/10;	
			
			}
		numeroTemporal2= numero2;
		numeroTemporal1= numeroTemporal1/10;
		
		}



		return resultado;

	}

	public static void main(String[]args){
		Bessie bessie = new Bessie();
		System.out.println(bessie.multiBessie(123,45));

	}
}