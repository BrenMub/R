public class Multiplos{

	public void imprimirMultiplos(int numero, int n){
		for(int i=1; i <= n; i=i+1){
			int resultado = numero*i;
			System.out.println(resultado);

		}
		


	}
	
	public static void main(String [] args){
		Multiplos multiplos= new Multiplos();
		multiplos.imprimirMultiplos(3,10);
	}
}