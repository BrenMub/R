public class NumeroArmstrong{



	public int contarCantidadNumeros(int numero){
		int potencia =1;
		int contador =0;
		while(numero!= numero%potencia){
			potencia= potencia*10;
			contador++;
		}
		return contador;
	}
	
	






	public static void main(String [] args){

		NumeroArmstrong armstrong= new NumeroArmstrong();
		System.out.println(armstrong.contarCantidadNumeros(888888));
			

	}


}


