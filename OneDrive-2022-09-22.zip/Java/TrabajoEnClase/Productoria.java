public class Productoria{

	public int calcularProductoria(int n, int m){
		int resultado=1;
		for(int i= n; i<=m;i++){
			resultado= resultado*i;

		}
		return resultado;
	}
	


	public static void main(String [] args){
		Productoria productoria= new Productoria();
		System.out.println(productoria.calcularProductoria(1,5));
	}
	
}