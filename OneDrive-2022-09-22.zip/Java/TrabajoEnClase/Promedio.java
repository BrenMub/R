public class Promedio{
	

	public int sumar( int n, int m){
		int resultado=0;
		for (int i=n; i<=m; i++){
			resultado= resultado + i;

		}
		return resultado;

		
	 }

	 public double calcularPromedio(int n, int m ){
	 	int resultado1= sumar(n,m)/2;
	 	return resultado1;
	 }





	public static void main(String [] args){
		Promedio promedio= new Promedio();
		
		System.out.println(promedio.calcularPromedio(3,5));

	}
}