public class SerieArmonica{
	public double fraccionArmonica(int numero){
		double contador=1;
		double resultado=0;
		double fraccion=0;
		while(contador<=numero){
			System.out.println(contador);
			fraccion= fraccion+ 1/contador;
			contador++;
		}
		return fraccion;
	}


	public double fraccion(int numero){
		double resultado=0;
		for(int i=1; i<=numero; i++){
			double d=i;
			resultado= resultado+ 1/d;

		}
		return resultado;
	}


	public static void main(String[]args){
		SerieArmonica serie= new SerieArmonica();
		Interfaz interfaz = new Interfaz();


		int numero1= interfaz.solicitarNumeroEntero("Digite un numero");
		System.out.println(serie.fraccionArmonica(numero1));
	}

	

	



	
}