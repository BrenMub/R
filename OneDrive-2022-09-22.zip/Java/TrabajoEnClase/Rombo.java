public class Rombo{

	public void imprimirFigura(int lineaMedia){
		String asterisco= "*";
		String espacio= " ";
		for(int i=1; i<= lineaMedia; i++){
			for(int j=1; j<= i; j++){
				System.out.print(espacio);
			}
			System.out.print(asterisco);
				
			}
	}
	public void imprimirFigura1(int lineaMedia){
		for(int i= lineaMedia-1; i>=1; i--){
			for(int j=1; j<=i; j++){
				System.out.print("*");

			}
			System.out.println(" ");

		}
	}

	

	



	public static void main(String[]args){
		Rombo figura= new Rombo();
		figura.imprimirFigura(6);
		
	}
	
}