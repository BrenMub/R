public class SerieTaylor{
	
}