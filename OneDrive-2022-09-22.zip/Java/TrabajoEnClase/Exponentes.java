public class Exponentes{

	public void calcularExponentes(int base, int exponente){
		int resultado=1;
		for(int i= 1; i<= exponente; i++){
			resultado= resultado*base;
		}
		
		System.out.println(resultado);


	}



	public static void main(String [] args){
		Exponentes exponente = new Exponentes();
		exponente.calcularExponentes(8,4);


		
	}
	
}