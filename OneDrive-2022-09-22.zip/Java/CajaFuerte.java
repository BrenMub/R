public class CajaFuerte{
	private boolean estaAbierta;       // escogi boolean porque la caja puede estar cerrada o abierta// 
	private int combinacion;       //escogi int ya que los numeros que se ingresan solo pueden ser enteros// 

public void setAbierta(boolean bool){
	this.estaAbierta= bool; 

}
public boolean getAbierta(){
	return estaAbierta; 
}
public void setCombinacion(int combinacion){
	this.combinacion= combinacion; 

}
public int getCombinacion(){
	return combinacion;
}



}