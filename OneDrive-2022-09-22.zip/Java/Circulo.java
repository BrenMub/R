public class Circulo{

	private double pi;
	private double circunferencia; 

public Circulo(){
	this.pi= 3.14159265;
	this.circunferencia= 0;
}
public double calcularCircunferencia(double diametro){
	circunferencia= circunferencia+ 2*pi*(diametro/2);
	return circunferencia;
}
}