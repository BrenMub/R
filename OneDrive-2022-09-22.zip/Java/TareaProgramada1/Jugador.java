public class Jugador{
	
	private Ficha [] fichasJugador;
	private String nombre;

	public Jugador(String nombre){

		fichasJugador = new Ficha [28];
		this.nombre = nombre;
	}

	public void setFichasJugador(Ficha [] fichasJugador){
		this.fichasJugador = fichasJugador;
	}



	public void imprimirFichasJugador(){ //Este método me imprime todas las fichas de los jugadores
		System.out.println("Fichas "+ nombre);
			for(int i=0; i<fichasJugador.length;i++){
				if(fichasJugador [i]!= null){ 
				System.out.print(i+ " : "+ fichasJugador[i].retornarDatos()+"  ");
				
				} 

				
			} System.out.println("");
		
	}

	public void asignarFicha(Ficha ficha){
		int contador=0;
		Boolean encontrar=false;
		while(encontrar==false){
			if(fichasJugador[contador] == null){
				encontrar = true;
				fichasJugador[contador] = ficha;
			}
		}

	}

	public Ficha getFichaPosicion(int posicion){
		return fichasJugador[posicion];
	}

	public void eliminarFicha(int posicion){
		fichasJugador[posicion]=null;

	}


} 