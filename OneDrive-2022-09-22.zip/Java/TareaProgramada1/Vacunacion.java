public class Vacunacion{







	public static void main(){
		Vacunacion vacunacion= new Vacunacion();
		double [] centralNorte={94.409, 124.763,144.345, 171.062, 197.544, 227.468, 261.465, 299.498};

		double [][] datosVacunacion= {{centralNorte}};
	}
	
}