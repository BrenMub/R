public class Mesa{
	
	private Ficha [] fichasMesa;
	private int contadorIzquierda;
	private int contadorDerecha;


	public Mesa(){
		fichasMesa= new Ficha[60];
		contadorIzquierda=29;
		contadorDerecha=30;
	}

	public void colocarIzquierda(Ficha ficha){
		fichasMesa[contadorIzquierda]= ficha;
		contadorIzquierda--;

	}

	public void colocarDerecha(Ficha ficha){
		fichasMesa[contadorDerecha]= ficha;
		contadorDerecha++; //Verificar que el contador se está actualizando y guardando
	}

	public void imprimirFichasMesa(){ //Este método me imprime todas las fichas del jugador1
		System.out.println("Fichas mesa: ");
			for(int i=0; i<fichasMesa.length;i++){
				if(fichasMesa[i]!= null){ 
				System.out.print(fichasMesa[i].retornarDatos()+"  ");
				
				} 

				
			} System.out.println("");
		
	}

 	public Boolean verificarInicial(Ficha ficha){
		Boolean jugar=false;
		if(ficha!=null){  
		int numero1= ficha.getNumero1();
		int numero2= ficha.getNumero2();
		int numeroVerificar = fichasMesa[contadorIzquierda+1].getNumero1();	
			if(numeroVerificar==numero1 || numeroVerificar==numero2){
				jugar=true;
			}
			
			numeroVerificar = fichasMesa[contadorDerecha-1].getNumero2();
			if(numeroVerificar==numero1 || numeroVerificar==numero2){
				jugar=true;

			}
		}

		 return jugar;
	}	

	public Boolean verificarGuardar(Ficha ficha, int colocar){
		Boolean jugar=false;
		int numero1= ficha.getNumero1();
		int numero2= ficha.getNumero2();
		if(colocar==0){
			int numeroVerificar = fichasMesa[contadorIzquierda+1].getNumero1();
				if(numeroVerificar==numero1 || numeroVerificar==numero2){
				jugar=true;
				if(numero1==numeroVerificar){
					int temporal = numero1;
					numero1 = numero2;
					numero2 = temporal;
				}
				Ficha ficha1 = new Ficha(numero1,numero2);
				colocarIzquierda(ficha1);

				}

		}
			
		if(colocar==1){
			int numeroVerificar = fichasMesa[contadorDerecha-1].getNumero2();
			if(numeroVerificar==numero1 || numeroVerificar==numero2){
				jugar=true;
				if(numero2==numeroVerificar){
					int temporal = numero1;
					numero1 = numero2;
					numero2 = temporal;
				}
				Ficha ficha2 = new Ficha(numero1,numero2);
				colocarDerecha(ficha2);
				}

		
		}
			
			


		 return jugar;
	}





}