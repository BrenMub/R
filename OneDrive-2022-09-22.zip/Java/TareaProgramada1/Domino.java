import javax.swing.JOptionPane;
public class Domino{

	private Ficha [] fichas;
	private Ficha [] fichasJugador1;
	private Ficha [] fichasJugador2;
	private Ficha [] fichasReserva;
	private Jugador jugador; 
	private Jugador jugador1;
	private Jugador jugador2;
	private Mesa mesaActual;
	private Boolean turno;



	
	public Domino(){  //Este método sirve para crear las fichas y las guarda de una vez 
		fichas = new Ficha [28]; 
		int contador1=0;
		for(int i=0; i<=6; i++){ 
			for(int j=i; j<=6;j++){
				Ficha ficha = new Ficha(i,j);
				fichas[contador1]=ficha;
				contador1++;
				
			}
			
		}

		revolver();
		jugador1 = new Jugador("Esaú");
		jugador2 = new Jugador("Brenda");
		mesaActual = new Mesa();
		turno =true;
		jugador= new Jugador(" ");



		
		int contador = 0;
		fichasJugador1= new Ficha [28];
		for(int i= 0; i<7; i++){
			fichasJugador1[i]= fichas[contador];
			contador++;
		}
		
		jugador1.setFichasJugador(fichasJugador1);


		fichasJugador2= new Ficha [28];
		for(int i=0; i<7; i++){
			fichasJugador2[i]= fichas[contador];
			contador++;
		}
		
		jugador2.setFichasJugador(fichasJugador2);

		
		fichasReserva= new Ficha[28];
		for(int i=0 ; i<14; i++){
			fichasReserva[i]= fichas[contador];
			contador++;
		}
		



	}


	public int recibirEnteroIzquierdaDerecha(){

		boolean cumple=false;
		int numero = 0;

		while(!cumple){

			String numeroN = JOptionPane.showInputDialog("Digite 0 si quiere jugar a la izquierda o 1 si quiere jugar a la derecha");

		
						try{
							numero = Integer.parseInt(numeroN);

							if(numero!=0 && numero!=1){
								System.out.println("El número digitado es invalido. Este debe ser 0 o 1.");
							}

							else{
								cumple=true;
									
							}
						}
						catch(NumberFormatException e){
							System.err.println("El valor digitado no es un número válido");
							JOptionPane.showMessageDialog(
								null, 
								"El valor digitado no es un número válido", 
								"Error", 
								JOptionPane.ERROR_MESSAGE);
						}
		}

	  	
			return numero;
	}

	public int recibirEnteroPosicion(){

		int numero = 0;
		Boolean cumple = false;

		while(!cumple){

		String numeroN = JOptionPane.showInputDialog("Digite el número de la ficha que desea utilizar");

		
			try{
				numero = Integer.parseInt(numeroN);
				cumple=true;

			}
			catch(NumberFormatException e){
				System.err.println("El valor digitado no es un número válido");
				JOptionPane.showMessageDialog(
				null, 
				"El valor digitado no es un número válido", 
				"Error", 
				JOptionPane.ERROR_MESSAGE);
			}
		}

	  	
			return numero;
	}

	public void revolver(){ // Este método revuelve las fichas aleatoriamente 
		for(int i=0; i < fichas.length; i++){
			int celda = (int)(Math.random()*28);
			Ficha temporal = fichas[i];
			fichas[i]=fichas[celda];
			fichas[celda]= temporal;
		}

	}
	

	
	public void imprimirReserva(){ //Este método me imprime todas las fichas del jugador2
		System.out.println("Fichas Reserva");
		for(int i=0; i<fichasReserva.length;i++){
				if(fichasReserva [i]!= null ){ 
					System.out.print(fichasReserva[i].retornarDatos()+"  ");
					
				}

		}
	}
	public void imprimirFichas(){ //Este método me imprime todas las fichas 
		for(int i=0; i<fichas.length;i++){
			System.out.print(fichas[i].retornarDatos()+"  ");
		}
	}

	public int buscarPrimeraFicha(){ //Este método busca la primera ficha y almacena su posicion en una variable int posicion.
		int posicion=0;
		int contador= 0;
			for(int j=6; j>=0; j--){
				for( int i=0; i<7; i++ ){
					if(contador==0){
				
						int numero1J1=jugador1.getFichaPosicion(i).getNumero1();
						int numero2J1=jugador1.getFichaPosicion(i).getNumero2();
						int numero1J2=jugador2.getFichaPosicion(i).getNumero1();
						int numero2J2=jugador2.getFichaPosicion(i).getNumero2();
		
						if(numero1J1== j && numero2J1==j){
						posicion= i;
						contador++;
						this.turno=true;
					 
						}
						else{
							if(numero1J2==j && numero2J2== j){
							posicion= i;
							contador++;
							this.turno=false;
							}
						}

					}
				}
			}
		return posicion;
	} 


		public void iniciarMesa(){ // Este método coloca la primera ficha en la mesa y elimina la ficha escogida del jugador que la puso en la mesa.
			int posicion = buscarPrimeraFicha();
			if(turno){

				Ficha ficha;
				ficha=jugador1.getFichaPosicion(posicion);
				mesaActual.colocarDerecha(ficha);
				jugador1.eliminarFicha(posicion);
				turno=false;

			}
			else{
				Ficha ficha;
				ficha=jugador2.getFichaPosicion(posicion);
				mesaActual.colocarDerecha(ficha);
				jugador2.eliminarFicha(posicion);
				turno=true;
			}


		}

		public Boolean verificar(Jugador jugador){
			int contador=0;
			Boolean jugar = false;
			while(jugar==false && contador<28){
				Ficha ficha = jugador.getFichaPosicion(contador);
				jugar= mesaActual.verificarInicial(ficha);
				contador++;

			}
			if(jugar==false){
				jugar=comer(jugador);
				System.out.println("me la comi");
			}


			return jugar;
		}

		public Boolean comer(Jugador jugador){
			int contador=0;
			Boolean jugar=false;
			while(jugar==false && contador<14){
				Ficha ficha = fichasReserva[contador];
				
				if(ficha!=null){
					jugador.asignarFicha(ficha);
					fichasReserva[contador] = null;
					if(mesaActual.verificarInicial(ficha)){
					jugar=true;
					}
				}
				contador++;
				jugador.imprimirFichasJugador();
				

			} return jugar;

		}

		public Boolean turnoJugador(Jugador jugador){
			Boolean jugar = verificar(jugador);
			Boolean estoyJugando=true;
			jugador.imprimirFichasJugador();


			if(jugar==false){
				jugar = comer(jugador); 
				System.out.println("comio");
			}

			if(jugar){
				while(estoyJugando){
					int a = recibirEnteroPosicion();
					Ficha ficha = jugador.getFichaPosicion(a);
					if(ficha!=null){
						int b = recibirEnteroIzquierdaDerecha();
						Boolean resultado =mesaActual.verificarGuardar(ficha,b);
						if(resultado){
							jugador.eliminarFicha(a);
							estoyJugando=false;
						}
						else{
							System.out.println("La ficha seleccionada no calza en la posición elegida");
						}

					}
					else{
						System.out.println("La posición selecciona es invalida");
					}

				}   
				

			}
			else{
				System.out.println("Paso");

			}

			return estoyJugando;		
			
		}

		public void jugar(){
			
			boolean juegoTerminado=acabarJuego(cambiarTurno());
			jugador1.imprimirFichasJugador();
			jugador2.imprimirFichasJugador();
			iniciarMesa();
			while(juegoTerminado==false){
				jugador=cambiarTurno();
				mesaActual.imprimirFichasMesa();
				turnoJugador(jugador);
				juegoTerminado=acabarJuego(jugador);
				this.turno=!turno;

			}
			

		}
		public Boolean acabarJuego(Jugador jugador){
			Boolean juegoTerminado=false;
			int contador=0;
			for(int i=0; i< 28; i++){
				Ficha ficha=jugador.getFichaPosicion(i);
				if(ficha==null){
					contador++;

					
					
				}
				if(contador==28){
					juegoTerminado= true;
					System.out.println("Se termino");

				}


			}
			return juegoTerminado;

		}
		public Jugador cambiarTurno(){
			if(this.turno==true){
				jugador=jugador1;

			}
			else{
				jugador=jugador2;
			}
			return jugador;

		
		}




		public Jugador getJugador1(){
			return jugador1;
		}

		public Jugador getJugador2(){
			return jugador2;
		}

		public Mesa getMesa(){
			return mesaActual;
		}


		


	public static void main(String []args){
		Domino fichas= new Domino();
		fichas.jugar();
	

		
		



		

	}


	
}