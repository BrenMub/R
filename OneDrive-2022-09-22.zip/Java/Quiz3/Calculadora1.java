public class Calculadora1 {
	public int elevar(int x, int n){
		int contador =1;
		int resultado=1;
		while(contador<=n){
			resultado=resultado*x;
			contador++;


		}
			return resultado;

	}
	public int calcularSucesion(int x, int n){
		int resultado1=0;
		for(int i=1; i<=n; i++){
			resultado1+= elevar(x,i);


		}
		return resultado1;
	}


	public static void main(String []args){
		Calculadora1 calculadora= new Calculadora1();
		Interfaz interfaz = new Interfaz();

		int numero1 = interfaz.solicitarNumeroEntero("Digite x");
		int numero2 = interfaz.solicitarNumeroEntero("Digite n");


		System.out.println(calculadora.calcularSucesion(numero1, numero2));


	}

	
}