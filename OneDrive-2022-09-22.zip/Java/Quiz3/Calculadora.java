public class Calculadora{
	public double  encontrarParteFraccionaria(double numero){
		int numeroTemporal= (int) (numero);
		double resultado= numeroTemporal- numero;
		return resultado;

		}

		


	
}