public class EjerciciosArreglo{
	public void imprimir(int [] arreglo){
		for(int i=0; i<arreglo.length; i++){
			System.out.print(arreglo [i]+ " ");
		}
	}
	public int buscarMayor(int [] arreglo){
		int mayor = arreglo[0];
		for(int i=1; i< arreglo.length; i++){
			if(mayor< arreglo [i]){
				mayor=arreglo[i];
			}
		}
		return mayor;

	}


	public static void main(String [] args){
		EjerciciosArreglo er= new EjerciciosArreglo();
		int [] miArreglo = {1,2,3,4,5};
		System.out.println(er.buscarMayor(miArreglo));

	}
}